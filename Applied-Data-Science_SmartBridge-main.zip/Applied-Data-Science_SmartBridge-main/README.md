# Applied-Data-Science_SmartBridge
The repository contains the Project folder, assignments folder, demonstration video of project and report.

A. Project Folder
B. Assignments
C. Report
D. Demonstration video.

**Drive Link for the demonstration video:**
https://drive.google.com/file/d/1Iaq2vy9neT_xhvZLCprNXHN7b1KYBaYK/view?usp=sharing

**Drive Link for the DataSet:**
https://drive.google.com/drive/folders/1dZGazqHtaPu4DoU_ZqR6ESvchAbQXhIj?usp=sharing
